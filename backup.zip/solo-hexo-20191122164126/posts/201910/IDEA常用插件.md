title: IDEA常用插件
date: '2019-10-30 09:27:09'
updated: '2019-10-30 09:27:09'
tags: [Idea]
permalink: /articles/2019/10/30/1572398829415.html
---
![](https://img.hacpai.com/bing/20180622.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)
##  activate-power-mode
最先介绍的就是这个装B插件了，让你的代码粒子化+抖动化。
![图片.png](https://img.hacpai.com/file/2019/09/图片-739b5ef8.png)

##  Background Image Plus
这又是一款装备B插件了，想想别人看到你的IDE有个美女或者异次元背景是怎样的，安装之后，在打开View选项，就可以看到Set Background Image选项了。
![图片.png](https://img.hacpai.com/file/2019/10/图片-35778246.png)


##  Alibaba Java Coding Guidelines
经过247天的持续研发，阿里巴巴于10月14日在杭州云栖大会上，正式发布众所期待的《阿里巴巴Java开发规约》扫描插件！该插件由阿里巴巴P3C项目组研发。P3C是世界知名的反潜机，专门对付水下潜水艇，寓意是扫描出所有潜在的代码隐患。

为了让开发者更加方便、快速将规范推动并实行起来，阿里巴巴基于手册内容，研发了一套自动化的IDE检测插件（IDEA、Eclipse）。该插件在扫描代码后，将不符合规约的代码按Blocker/Critical/Major三个等级显示在下方，甚至在IDEA上，我们还基于Inspection机制提供了实时检测功能，编写代码的同时也能快速发现问题所在。对于历史代码，部分规则实现了批量一键修复的功能，如此爽心悦目的功能是不是很值得拥有？提升代码质量，提高团队研发效能，插件将会一路同行。
![图片.png](https://img.hacpai.com/file/2019/09/图片-bb8d8d90.png)
![图片.png](https://img.hacpai.com/file/2019/09/图片-95222cdb.png)

##  iBATIS/MyBatis plugin
轻松通过快捷键找到MyBatis中对应的Mapper和XML，CTRL+ALT+B
![图片.png](https://img.hacpai.com/file/2019/09/图片-6121aec1.png)
![图片.png](https://img.hacpai.com/file/2019/09/图片-c50f72f8.png)

##  Stack Overflow
编码中几乎所有遇到的错误，都可以在Stack Overflow上找到，因此这个插件可称之为贴心助手，只不过默认使用Google搜索，大家注意。
![图片.png](https://img.hacpai.com/file/2019/09/图片-0f23f069.png)
![图片.png](https://img.hacpai.com/file/2019/09/图片-cf7860d5.png)

##  Lombok
![图片.png](https://img.hacpai.com/file/2019/09/图片-731f3bc0.png)

##  aiXcoder
* **智能代码提示**
    
    她用强大的深度学习引擎，能给出更加精确的代码提示；
    
* **代码风格检查**
    
    她有代码风格智能检查能力，帮助开发者改善代码质量；
    
* **编程模式学习**
    
    她能自主学习开发者的编程模式，边用边学，越用越强


##  翻译插件Translation
开发的时候经常会遇到看不懂的英语单词，再去百度多麻烦，这里推荐这款翻译插件，插件名称叫做，安装后选中单词按下快捷键ALT+1即可。重新打开idea，选择一个单词或者一个句子，按ctrl + shift + y 进行翻译，如果没反应说明快捷键无效，应该是系统中存在其他的应用占用了这个快捷键，改掉即可，或者选择右键，Translatate。
![图片.png](https://img.hacpai.com/file/2019/09/图片-55adf816.png)


## SMartIM

IntelliJ IDEA 上的 SmartIM 插件，可以在 IDEA 中使用 QQ,微信 聊天



