title: Activity从入门到 入土（ 入门实例）
date: '2019-10-31 16:40:31'
updated: '2019-10-31 16:40:31'
tags: [Activity]
permalink: /articles/2019/10/31/1572511231676.html
---
![](https://img.hacpai.com/bing/20180824.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 一、前言

在上一节中我们对[activiti进行了基本的介绍]activiti进行了基本的介绍，同时介绍了基本的概念。

这一节，我将用一个入门程序，介绍如何使用activiti。

### 二、环境准备

#### 2.1、编译器选择

这里我们使用`Idea`进行工作流开发，虽然Idea对于工作流的友好度不是很好，因为会有一些小的bug，但是，Idea对于Java的开发还是非常的好的。

在用Idea开发之前，我们需要在idea中安装**bpmn开发的插件**。方法如下

**打开设置**
![图片.png](https://img.hacpai.com/file/2019/09/图片-936f11df.png)


**选择plugins**  
![图片.png](https://img.hacpai.com/file/2019/09/图片-79e328c6.png)


  
**搜索actiBPM**  

![图片.png](https://img.hacpai.com/file/2019/09/图片-194ee7de.png)


**重启idea，新建文件**

如果能够找到下面的创建方法，就代表成功了。  
![图片.png](https://img.hacpai.com/file/2019/09/图片-86388646.png)


**新建后出现下面的编辑页面**  

![图片.png](https://img.hacpai.com/file/2019/09/图片-ee7b88f6.png)


到现在，bpmn编辑插件就准备好了。

#### 2.2、其他环境准备

* JDK:1.8
* 数据库：mysql5.7
* activiti jar包：使用maven依赖

### 三、入门程序

#### 3.1、新建maven项目

新建的maven项目目录如下  
![图片.png](https://img.hacpai.com/file/2019/09/图片-616c59d6.png)


#### 3.2、添加pom依赖

这里需要的pom依赖有以下几个：junit、druid、mysql、lombok（日志）、activiti

```
<?xml version="1.0" encoding="UTF-8"?>

<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.sihai</groupId>
    <artifactId>acitvitiDemo</artifactId>
    <version>1.0-SNAPSHOT</version>


    <properties>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <maven.compiler.source>1.8</maven.compiler.source>
        <maven.compiler.target>1.8</maven.compiler.target>
    </properties>

    <dependencies>
        <dependency>
            <groupId>junit</groupId>
            <artifactId>junit</artifactId>
            <version>4.12</version>
            <scope>test</scope>
        </dependency>

        <!-- druid -->
        <dependency>
            <groupId>com.alibaba</groupId>
            <artifactId>druid</artifactId>
            <version>1.1.12</version>
        </dependency>

        <!-- mysql -->
        <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
            <version>5.1.30</version>
        </dependency>

        <!-- lombok -->
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <version>1.16.12</version>
        </dependency>

        <!-- logback -->
        <dependency>
            <groupId>ch.qos.logback</groupId>
            <artifactId>logback-core</artifactId>
            <version>1.1.8</version>
        </dependency>
        <dependency>
            <groupId>ch.qos.logback</groupId>
            <artifactId>logback-classic</artifactId>
            <version>1.1.8</version>
        </dependency>
        <dependency>
            <groupId>org.slf4j</groupId>
            <artifactId>slf4j-api</artifactId>
            <version>1.7.22</version>
        </dependency>

        <dependency>
            <groupId>org.activiti</groupId>
            <artifactId>activiti-engine</artifactId>
            <version>5.22.0</version>
        </dependency>
    </dependencies>

    <build>
        <pluginManagement><!-- lock down plugins versions to avoid using Maven defaults (may be moved to parent pom) -->
            <plugins>
                <plugin>
                    <groupId>org.apache.maven.plugins</groupId>
                    <artifactId>maven-compiler-plugin</artifactId>
                    <configuration>
                        <source>1.8</source>
                        <target>1.8</target>
                    </configuration>
                </plugin>
            </plugins>
        </pluginManagement>
    </build>
</project>

```

#### 3.3、日志配置文件

```
<?xml version="1.0" encoding="UTF-8"?>
<configuration scan="true" scanPeriod="60 seconds">

    <appender name="STDOUT" class="ch.qos.logback.core.ConsoleAppender">
        <encoder>
            <pattern>%d{yyyy-MM-dd HH:mm:ss.SSS} [%thread] %-5level %logger - %msg%n</pattern>
        </encoder>
    </appender>

    <!--<appender name="permission" class="ch.qos.logback.core.rolling.RollingFileAppender">-->
    <!--<file>${catalina.home}/logs/permission.log</file>-->
    <!--<rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">-->
    <!--<FileNamePattern>${catalina.home}/logs/permission.%d{yyyy-MM-dd}.log.gz</FileNamePattern>-->
    <!--</rollingPolicy>-->
    <!--<layout class="ch.qos.logback.classic.PatternLayout">-->
    <!--<pattern>%d{yyyy-MM-dd HH:mm:ss.SSS} [%thread] %-5level %logger - %msg%n</pattern>-->
    <!--</layout>-->
    <!--</appender>-->
    <!---->
    <!--<logger name="xxx" level="INFO">-->
    <!--<appender-ref ref="permission"/>-->
    <!--</logger>-->

    <!-- TRACE < DEBUG < INFO < WARN < ERROR -->
    <root level="INFO">
        <appender-ref ref="STDOUT"/>
    </root>

</configuration>

```

#### 3.4、测试实例

下面是添加一个junit测试实例，通过测试生成activiti底层需要的数据库表，总共有25张，如果数据库生成了25张表结构，则说明成功！

```
/**
 * @Author Anthony
 * @Description 生成activiti底层数据库表结构
 * @Date 16:24 2019/9/26
 * @Param
 * @return
 **/
public class Activiti_01 {
    /**
     * @return void
     * @Author Anthony
     * @Description //生成数据库表结构
     * @Date 20:57 2019/9/26
     * @Param []
     **/
    @Test
    public void test_createDatabase() {
        // 创建流程引擎配置信息对象
        ProcessEngineConfiguration pec = ProcessEngineConfiguration
                .createStandaloneProcessEngineConfiguration();
        // 设置数据库的类型
        pec.setDatabaseType("mysql");
        // 设置创建数据库的方式
//        ProcessEngineConfiguration.DB_SCHEMA_UPDATE_TRUE(true);//如果没有数据库表就会创建数据库表，有的话就修改表结构.
        // ProcessEngineConfiguration.DB_SCHEMA_UPDATE_FALSE(false): 不会创建数据库表
        // ProcessEngineConfiguration.DB_SCHEMA_UPDATE_CREATE_DROP(create-drop): 先创建、再删除.
        pec.setDatabaseSchemaUpdate("true");
        // 设置数据库驱动
        pec.setJdbcDriver("com.mysql.jdbc.Driver");
        // 设置jdbcURL
        pec.setJdbcUrl("jdbc:mysql://localhost:3306/activitiTest?useUnicode=true&characterEncoding=UTF-8");
        // 设置用户名
        pec.setJdbcUsername("root");
        // 设置密码

        pec.setJdbcPassword("root");

        pec.setJdbcPassword("XXXX");

        // 构建流程引擎对象
        ProcessEngine pe = pec.buildProcessEngine(); // 调用访方法才会创建数据表
        // 调用close方法时，才会删除
        pe.close();
    }
}

```

#### 3.5、运行测试实例

运行上面的测试实例后，将会生成下面的25张表结构。

**日志信息**  

![图片.png](https://img.hacpai.com/file/2019/09/图片-be3dc7f6.png)


**表结构**  

![图片.png](https://img.hacpai.com/file/2019/09/图片-10892a6f.png)


### 四、总结

通过上面是入门实例，就将activiti的环境准备好了！



