title: Java多线程系列（四） JUC集合 之 ConcurrentHashMap
date: '2019-11-12 15:28:11'
updated: '2019-11-12 15:28:11'
tags: [Java多线程系列]
permalink: /articles/2019/11/12/1573543691432.html
---
![](https://img.hacpai.com/bing/20190324.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### **ConcurrentHashMap介绍**

ConcurrentHashMap是线程安全的哈希表。HashMap, Hashtable, ConcurrentHashMap之间的关联如下：

 

**　　HashMap**是非线程安全的哈希表，常用于单线程程序中。

**　　Hashtable**是线程安全的哈希表，它是通过synchronized来保证线程安全的；即，多线程通过同一个“对象的同步锁”来实现并发控制。Hashtable在线程竞争激烈时，效率比较低(此时建议使用ConcurrentHashMap)！因为当一个线程访问Hashtable的同步方法时，其它线程就访问Hashtable的同步方法时，可能会进入阻塞状态。

　　**ConcurrentHashMap**是线程安全的哈希表，它是通过“锁分段”来保证线程安全的。ConcurrentHashMap将哈希表分成许多片段(Segment)，每一个片段除了保存哈希表之外，本质上也是一个“可重入的互斥锁”(ReentrantLock)。多线程对同一个片段的访问，是互斥的；但是，对于不同片段的访问，却是可以同步进行的。

### **ConcurrentHashMap原理和数据结构**

要想搞清ConcurrentHashMap，必须先弄清楚它的数据结构：

![图片.png](https://img.hacpai.com/file/2019/10/图片-bfcf9d58.png)

(01) ConcurrentHashMap继承于AbstractMap抽象类。  
  (02) Segment是ConcurrentHashMap中的内部类，它就是ConcurrentHashMap中的“锁分段”对应的存储结构。ConcurrentHashMap与Segment是组合关系，1个ConcurrentHashMap对象包含若干个Segment对象。在代码中，这表现为ConcurrentHashMap类中存在“Segment数组”成员。  
  (03) Segment类继承于ReentrantLock类，所以Segment本质上是一个可重入的互斥锁。  
  (04) HashEntry也是ConcurrentHashMap的内部类，是单向链表节点，存储着key-value键值对。Segment与HashEntry是组合关系，Segment类中存在“HashEntry数组”成员，“HashEntry数组”中的每个HashEntry就是一个单向链表。

  对于多线程访问对一个“哈希表对象”竞争资源，Hashtable是通过一把锁来控制并发；而ConcurrentHashMap则是将哈希表分成许多片段，对于每一个片段分别通过一个互斥锁来控制并发。ConcurrentHashMap对并发的控制更加细腻，它也更加适应于高并发场景！

下面从ConcurrentHashMap的创建，获取，添加，删除这4个方面对ConcurrentHashMap进行分析。

**1 创建**

下面以ConcurrentHashMap(int initialCapacity,float loadFactor, int concurrencyLevel)来进行说明。




```
@SuppressWarnings("unchecked")
public ConcurrentHashMap(int initialCapacity,
                         float loadFactor, int concurrencyLevel) {
    // 参数有效性判断
    if (!(loadFactor > 0) || initialCapacity < 0 || concurrencyLevel <= 0)
        throw new IllegalArgumentException();
    // concurrencyLevel是“用来计算segments的容量”
    if (concurrencyLevel > MAX_SEGMENTS)
        concurrencyLevel = MAX_SEGMENTS;
    int sshift = 0;
    int ssize = 1;
    // ssize=“大于或等于concurrencyLevel的最小的2的N次方值”
    while (ssize < concurrencyLevel) {
        ++sshift;
        ssize <<= 1;
    }
    // 初始化segmentShift和segmentMask
    this.segmentShift = 32 - sshift;
    this.segmentMask = ssize - 1;
    // 哈希表的初始容量
    // 哈希表的实际容量=“segments的容量” x “segments中数组的长度”
    if (initialCapacity > MAXIMUM_CAPACITY)
        initialCapacity = MAXIMUM_CAPACITY;
    // “哈希表的初始容量” / “segments的容量”
    int c = initialCapacity / ssize;
    if (c * ssize < initialCapacity)
        ++c;
    // cap就是“segments中的HashEntry数组的长度”
    int cap = MIN_SEGMENT_TABLE_CAPACITY;
    while (cap < c)
        cap <<= 1;
    // segments
    Segment<K,V> s0 =
        new Segment<K,V>(loadFactor, (int)(cap * loadFactor),
                         (HashEntry<K,V>[])new HashEntry[cap]);
    Segment<K,V>[] ss = (Segment<K,V>[])new Segment[ssize];
    UNSAFE.putOrderedObject(ss, SBASE, s0); // ordered write of segments[0]
    this.segments = ss;
}
```

**说明**：  
(01) 前面我们说过，ConcurrentHashMap采用了“锁分段”技术；在代码中，它通过“segments数组”对象来保存各个分段。segments的定义如下：

```
final Segment<K,V>[] segments;
```
concurrencyLevel的作用就是用来计算segments数组的容量大小。先计算出“大于或等于concurrencyLevel的最小的2的N次方值”，然后将其保存为“segments的容量大小(ssize)”。  
(02) initialCapacity是哈希表的初始容量。需要注意的是，哈希表的实际容量=“segments的容量” x “segments中数组的长度”。  
(03) loadFactor是加载因子。它是哈希表在其容量自动增加之前可以达到多满的一种尺度。

  
ConcurrentHashMap的构造函数中涉及到的非常重要的一个结构体，它就是Segment。下面看看Segment的声明：

```
static final class Segment<K,V> extends ReentrantLock implements Serializable {
    ...

    transient volatile HashEntry<K,V>[] table;
    // threshold阈，是哈希表在其容量自动增加之前可以达到多满的一种尺度。
    transient int threshold;
    // loadFactor是加载因子
    final float loadFactor;

    Segment(float lf, int threshold, HashEntry<K,V>[] tab) {
        this.loadFactor = lf;
        this.threshold = threshold;
        this.table = tab;
    }

    ...
}
```
**说明**：Segment包含HashEntry数组，HashEntry保存了哈希表中的键值对。  
此外，还需要说明的Segment继承于ReentrantLock。这意味着，Segment本质上就是可重入的互斥锁。

HashEntry的源码如下：
```
static final class HashEntry<K,V> {
    final int hash;    // 哈希值
    final K key;       // 键
    volatile V value;  // 值
    volatile HashEntry<K,V> next; // 下一个HashEntry节点

    HashEntry(int hash, K key, V value, HashEntry<K,V> next) {
        this.hash = hash;
        this.key = key;
        this.value = value;
        this.next = next;
    }

    ...
}
```
**说明**：和HashMap的节点一样，HashEntry也是链表。这就说明，ConcurrentHashMap是链式哈希表，它是通过“拉链法”来解决哈希冲突的。

 

**2 获取**

下面以get(Object key)为例，对ConcurrentHashMap的获取方法进行说明。

```
public V get(Object key) {
    Segment<K,V> s; // manually integrate access methods to reduce overhead
    HashEntry<K,V>[] tab;
    int h = hash(key);
    long u = (((h >>> segmentShift) & segmentMask) << SSHIFT) + SBASE;
    // 获取key对应的Segment片段。
    // 如果Segment片段不为null，则在“Segment片段的HashEntry数组中”中找到key所对应的HashEntry列表；
    // 接着遍历该HashEntry链表，找到于key-value键值对对应的HashEntry节点。
    if ((s = (Segment<K,V>)UNSAFE.getObjectVolatile(segments, u)) != null &&
        (tab = s.table) != null) {
        for (HashEntry<K,V> e = (HashEntry<K,V>) UNSAFE.getObjectVolatile
                 (tab, ((long)(((tab.length - 1) & h)) << TSHIFT) + TBASE);
             e != null; e = e.next) {
            K k;
            if ((k = e.key) == key || (e.hash == h && key.equals(k)))
                return e.value;
        }
    }
    return null;
}
```
**说明**：get(Object key)的作用是返回key在ConcurrentHashMap哈希表中对应的值。  
它首先根据key计算出来的哈希值，获取key所对应的Segment片段。  
如果Segment片段不为null，则在“Segment片段的HashEntry数组中”中找到key所对应的HashEntry列表。Segment包含“HashEntry数组”对象，而每一个HashEntry本质上是一个单向链表。  
接着遍历该HashEntry链表，找到于key-value键值对对应的HashEntry节点。

下面是hash()的源码
```
private int hash(Object k) {
    int h = hashSeed;

    if ((0 != h) && (k instanceof String)) {
        return sun.misc.Hashing.stringHash32((String) k);
    }

    h ^= k.hashCode();

    // Spread bits to regularize both segment and index locations,
    // using variant of single-word Wang/Jenkins hash.
    h += (h <<  15) ^ 0xffffcd7d;
    h ^= (h >>> 10);
    h += (h <<   3);
    h ^= (h >>>  6);
    h += (h <<   2) + (h << 14);
    return h ^ (h >>> 16);
}
```
**3 增加**

下面以put(K key, V value)来对ConcurrentHashMap中增加键值对来进行说明。
```
public V put(K key, V value) {
    Segment<K,V> s;
    if (value == null)
        throw new NullPointerException();
    // 获取key对应的哈希值
    int hash = hash(key);
    int j = (hash >>> segmentShift) & segmentMask;
    // 如果找不到该Segment，则新建一个。
    if ((s = (Segment<K,V>)UNSAFE.getObject          // nonvolatile; recheck
         (segments, (j << SSHIFT) + SBASE)) == null) // in ensureSegment
        s = ensureSegment(j);
    return s.put(key, hash, value, false);
}
```
**说明**：  
(01) put()根据key获取对应的哈希值，再根据哈希值找到对应的Segment片段。如果Segment片段不存在，则新增一个Segment。  
(02) 将key-value键值对添加到Segment片段中。

```
final V put(K key, int hash, V value, boolean onlyIfAbsent) {
    // tryLock()获取锁，成功返回true，失败返回false。
    // 获取锁失败的话，则通过scanAndLockForPut()获取锁，并返回”要插入的key-value“对应的”HashEntry链表“。
    HashEntry<K,V> node = tryLock() ? null :
        scanAndLockForPut(key, hash, value);
    V oldValue;
    try {
        // tab代表”当前Segment中的HashEntry数组“
        HashEntry<K,V>[] tab = table;
        //  根据”hash值“获取”HashEntry数组中对应的HashEntry链表“
        int index = (tab.length - 1) & hash;
        HashEntry<K,V> first = entryAt(tab, index);
        for (HashEntry<K,V> e = first;;) {
            // 如果”HashEntry链表中的当前HashEntry节点“不为null，
            if (e != null) {
                K k;
                // 当”要插入的key-value键值对“已经存在于”HashEntry链表中“时，先保存原有的值。
                // 若”onlyIfAbsent“为true，即”要插入的key不存在时才插入”，则直接退出；
                // 否则，用新的value值覆盖原有的原有的值。
                if ((k = e.key) == key ||
                    (e.hash == hash && key.equals(k))) {
                    oldValue = e.value;
                    if (!onlyIfAbsent) {
                        e.value = value;
                        ++modCount;
                    }
                    break;
                }
                e = e.next;
            }
            else {
                // 如果node非空，则将first设置为“node的下一个节点”。
                // 否则，新建HashEntry链表
                if (node != null)
                    node.setNext(first);
                else
                    node = new HashEntry<K,V>(hash, key, value, first);
                int c = count + 1;
                // 如果添加key-value键值对之后，Segment中的元素超过阈值(并且，HashEntry数组的长度没超过限制)，则rehash；
                // 否则，直接添加key-value键值对。
                if (c > threshold && tab.length < MAXIMUM_CAPACITY)
                    rehash(node);
                else
                    setEntryAt(tab, index, node);
                ++modCount;
                count = c;
                oldValue = null;
                break;
            }
        }
    } finally {
        // 释放锁
        unlock();
    }
    return oldValue;
}
```
**说明**：  
put()的作用是将key-value键值对插入到“当前Segment对应的HashEntry中”，在插入前它会获取Segment对应的互斥锁，插入后会释放锁。具体的插入过程如下：  
(01) 首先根据“hash值”获取“当前Segment的HashEntry数组对象”中的“HashEntry节点”，每个HashEntry节点都是一个单向链表。  
(02) 接着，遍历HashEntry链表。  
       若在遍历HashEntry链表时，找到与“要key-value键值对”对应的节点，即“要插入的key-value键值对”的key已经存在于HashEntry链表中。则根据onlyIfAbsent进行判断，若onlyIfAbsent为true，即“当要插入的key不存在时才插入”，则不进行插入，直接返回；否则，用新的value值覆盖原始的value值，然后再返回。  
       若在遍历HashEntry链表时，没有找到与“要key-value键值对”对应的节点。当node!=null时，即在scanAndLockForPut()获取锁时，已经新建了key-value对应的HashEntry节点，则”将HashEntry添加到Segment中“；否则，新建key-value对应的HashEntry节点，然后再“将HashEntry添加到Segment中”。 在”将HashEntry添加到Segment中“前，会判断是否需要rehash。如果在添加key-value键值之后，容量会超过阈值，并且HashEntry数组的长度没有超过限制，则进行rehash；否则，直接通过setEntryAt()将key-value键值对添加到Segment中。

在介绍rehash()和setEntryAt()之前，我们先看看自旋函数scanAndLockForPut()。下面是它的源码：

```
private HashEntry<K,V> scanAndLockForPut(K key, int hash, V value) {
    // 第一个HashEntry节点
    HashEntry<K,V> first = entryForHash(this, hash);
    // 当前的HashEntry节点
    HashEntry<K,V> e = first;
    HashEntry<K,V> node = null;
    // 重复计数(自旋计数器)
    int retries = -1; // negative while locating node

    // 查找”key-value键值对“在”HashEntry链表上对应的节点“；
    // 若找到的话，则不断的自旋；在自旋期间，若通过tryLock()获取锁成功则返回；否则自旋MAX_SCAN_RETRIES次数之后，强制获取”锁“并退出。
    // 若没有找到的话，则新建一个HashEntry链表。然后不断的自旋。
    // 此外，若在自旋期间，HashEntry链表的表头发生变化；则重新进行查找和自旋工作！
    while (!tryLock()) {
        HashEntry<K,V> f; // to recheck first below
        // 1. retries<0的处理情况
        if (retries < 0) {
            // 1.1 如果当前的HashEntry节点为空(意味着，在该HashEntry链表上上没有找到”要插入的键值对“对应的节点)，而且node=null；则新建HashEntry链表。
            if (e == null) {
                if (node == null) // speculatively create node
                    node = new HashEntry<K,V>(hash, key, value, null);
                retries = 0;
            }
            // 1.2 如果当前的HashEntry节点是”要插入的键值对在该HashEntry上对应的节点“，则设置retries=0
            else if (key.equals(e.key))
                retries = 0;
            // 1.3 设置为下一个HashEntry。
            else
                e = e.next;
        }
        // 2. 如果自旋次数超过限制，则获取“锁”并退出
        else if (++retries > MAX_SCAN_RETRIES) {
            lock();
            break;
        }
        // 3. 当“尝试了偶数次”时，就获取“当前Segment的第一个HashEntry”，即f。
        // 然后，通过f!=first来判断“当前Segment的第一个HashEntry是否发生了改变”。
        // 若是的话，则重置e，first和retries的值，并重新遍历。
        else if ((retries & 1) == 0 &&
                 (f = entryForHash(this, hash)) != first) {
            e = first = f; // re-traverse if entry changed
            retries = -1;
        }
    }
    return node;
}
```

**说明**：  
scanAndLockForPut()的目标是获取锁。流程如下：  
    它首先会调用entryForHash()，根据hash值获取”当前Segment中对应的HashEntry节点(first)，即找到对应的HashEntry链表“。  
    紧接着进入while循环。在while循环中，它会遍历”HashEntry链表(e)“，查找”要插入的key-value键值对“在”该HashEntry链表上对应的节点“。  
         若找到的话，则不断的自旋，即不断的执行while循环。在自旋期间，若通过tryLock()获取锁成功则返回；否则，在自旋MAX_SCAN_RETRIES次数之后，强制获取锁并退出。  
         若没有找到的话，则新建一个HashEntry链表，然后不断的自旋。在自旋期间，若通过tryLock()获取锁成功则返回；否则，在自旋MAX_SCAN_RETRIES次数之后，强制获取锁并退出。  
     此外，若在自旋期间，HashEntry链表的表头发生变化；则重新进行查找和自旋工作！

理解scanAndLockForPut()时，务必要联系”哈希表“的数据结构。一个Segment本身就是一个哈希表，Segment中包含了”HashEntry数组“对象，而每一个HashEntry对象本身是一个”单向链表“。

 

下面看看rehash()的实现代码。

```
private void rehash(HashEntry<K,V> node) {
    HashEntry<K,V>[] oldTable = table;
    // ”Segment中原始的HashEntry数组的长度“
    int oldCapacity = oldTable.length;
    // ”Segment中新HashEntry数组的长度“
    int newCapacity = oldCapacity << 1;
    // 新的阈值
    threshold = (int)(newCapacity * loadFactor);
    // 新的HashEntry数组
    HashEntry<K,V>[] newTable =
        (HashEntry<K,V>[]) new HashEntry[newCapacity];
    int sizeMask = newCapacity - 1;
    // 遍历”原始的HashEntry数组“，
    // 将”原始的HashEntry数组“中的每个”HashEntry链表“的值，都复制到”新的HashEntry数组的HashEntry元素“中。
    for (int i = 0; i < oldCapacity ; i++) {
        // 获取”原始的HashEntry数组“中的”第i个HashEntry链表“
        HashEntry<K,V> e = oldTable[i];
        if (e != null) {
            HashEntry<K,V> next = e.next;
            int idx = e.hash & sizeMask;
            if (next == null)   //  Single node on list
                newTable[idx] = e;
            else { // Reuse consecutive sequence at same slot
                HashEntry<K,V> lastRun = e;
                int lastIdx = idx;
                for (HashEntry<K,V> last = next;
                     last != null;
                     last = last.next) {
                    int k = last.hash & sizeMask;
                    if (k != lastIdx) {
                        lastIdx = k;
                        lastRun = last;
                    }
                }
                newTable[lastIdx] = lastRun;
                // 将”原始的HashEntry数组“中的”HashEntry链表(e)“的值，都复制到”新的HashEntry数组的HashEntry“中。
                for (HashEntry<K,V> p = e; p != lastRun; p = p.next) {
                    V v = p.value;
                    int h = p.hash;
                    int k = h & sizeMask;
                    HashEntry<K,V> n = newTable[k];
                    newTable[k] = new HashEntry<K,V>(h, p.key, v, n);
                }
            }
        }
    }
    // 将新的node节点添加到“Segment的新HashEntry数组(newTable)“中。
    int nodeIndex = node.hash & sizeMask; // add the new node
    node.setNext(newTable[nodeIndex]);
    newTable[nodeIndex] = node;
    table = newTable;
}
```
**说明**：rehash()的作用是将”Segment的容量“变为”原始的Segment容量的2倍“。  
在将原始的数据拷贝到“新的Segment”中后，会将新增加的key-value键值对添加到“新的Segment”中。

setEntryAt()的源码如下：

```
static final <K,V> void setEntryAt(HashEntry<K,V>[] tab, int i,
                                   HashEntry<K,V> e) {
    UNSAFE.putOrderedObject(tab, ((long)i << TSHIFT) + TBASE, e);
}
```
UNSAFE是Segment类中定义的“静态sun.misc.Unsafe”对象。源码如下：
```
static final sun.misc.Unsafe UNSAFE;
```
Unsafe.java在openjdk6中的路径是：openjdk6/jdk/src/share/classes/sun/misc/Unsafe.java。其中，putOrderedObject()的源码下：
```
public native void putOrderedObject(Object o, long offset, Object x);
```
**说明**：putOrderedObject()是一个本地方法。  
它会设置obj对象中offset偏移地址对应的object型field的值为指定值。它是一个有序或者有延迟的putObjectVolatile()方法，并且不保证值的改变被其他线程立即看到。只有在field被volatile修饰并且期望被意外修改的时候，使用putOrderedObject()才有用。

总之，setEntryAt()的目的是设置tab中第i位置元素的值为e，且该设置会有延迟。

 

**4 删除**

下面以remove(Object key)来对ConcurrentHashMap中的删除操作来进行说明。

```
public V remove(Object key) {
    int hash = hash(key);
    // 根据hash值，找到key对应的Segment片段。
    Segment<K,V> s = segmentForHash(hash);
    return s == null ? null : s.remove(key, hash, null);
}
```
**说明**：remove()首先根据“key的计算出来的哈希值”找到对应的Segment片段，然后再从该Segment片段中删除对应的“key-value键值对”。

remove()的方法如下：
```
final V remove(Object key, int hash, Object value) {
    // 尝试获取Segment对应的锁。
    // 尝试失败的话，则通过scanAndLock()来获取锁。
    if (!tryLock())
        scanAndLock(key, hash);
    V oldValue = null;
    try {
        // 根据“hash值”找到“Segment的HashEntry数组”中对应的“HashEntry节点(e)”，该HashEntry节点是一HashEntry个链表。
        HashEntry<K,V>[] tab = table;
        int index = (tab.length - 1) & hash;
        HashEntry<K,V> e = entryAt(tab, index);
        HashEntry<K,V> pred = null;
        // 遍历“HashEntry链表”，删除key-value键值对
        while (e != null) {
            K k;
            HashEntry<K,V> next = e.next;
            if ((k = e.key) == key ||
                (e.hash == hash && key.equals(k))) {
                V v = e.value;
                if (value == null || value == v || value.equals(v)) {
                    if (pred == null)
                        setEntryAt(tab, index, next);
                    else
                        pred.setNext(next);
                    ++modCount;
                    --count;
                    oldValue = v;
                }
                break;
            }
            pred = e;
            e = next;
        }
    } finally {
        // 释放锁
        unlock();
    }
    return oldValue;
}
```

**说明**：remove()的目的就是删除key-value键值对。在删除之前，它会获取到Segment的互斥锁，在删除之后，再释放锁。  
它的删除过程也比较简单，它会先根据hash值，找到“Segment的HashEntry数组”中对应的“HashEntry”节点。根据Segment的数据结构，我们知道Segment中包含一个HashEntry数组对象，而每一个HashEntry本质上是一个单向链表。 在找到“HashEntry”节点之后，就遍历该“HashEntry”节点对应的链表，找到key-value键值对对应的节点，然后删除。

下面对scanAndLock()进行说明。它的源码如下：
```
private void scanAndLock(Object key, int hash) {
    // 第一个HashEntry节点
    HashEntry<K,V> first = entryForHash(this, hash);
    HashEntry<K,V> e = first;
    int retries = -1;

    // 查找”key-value键值对“在”HashEntry链表上对应的节点“；
    // 无论找没找到，最后都会不断的自旋；在自旋期间，若通过tryLock()获取锁成功则返回；否则自旋MAX_SCAN_RETRIES次数之后，强制获取”锁“并退出。
    // 若在自旋期间，HashEntry链表的表头发生变化；则重新进行查找和自旋！
    while (!tryLock()) {
        HashEntry<K,V> f;
        if (retries < 0) {
            // 如果“遍历完该HashEntry链表，仍然没找到”要删除的键值对“对应的节点”
            // 或者“在该HashEntry链表上找到”要删除的键值对“对应的节点”，则设置retries=0
            // 否则，设置e为下一个HashEntry节点。
            if (e == null || key.equals(e.key))
                retries = 0;
            else
                e = e.next;
        }
        // 自旋超过限制次数之后，获取锁并退出。
        else if (++retries > MAX_SCAN_RETRIES) {
            lock();
            break;
        }
        // 当“尝试了偶数次”时，就获取“当前Segment的第一个HashEntry”，即f。
        // 然后，通过f!=first来判断“当前Segment的第一个HashEntry是否发生了改变”。
        // 若是的话，则重置e，first和retries的值，并重新遍历。
        else if ((retries & 1) == 0 &&
                 (f = entryForHash(this, hash)) != first) {
            e = first = f;
            retries = -1;
        }
    }
}
```
**说明**：scanAndLock()的目标是获取锁。它的实现与scanAndLockForPut()类似，这里就不再过多说明。

 

**总结**：ConcurrentHashMap是线程安全的哈希表，它是通过“锁分段”来实现的。ConcurrentHashMap中包括了“Segment(锁分段)数组”，每个Segment就是一个哈希表，而且也是可重入的互斥锁。第一，Segment是哈希表表现在，Segment包含了“HashEntry数组”，而“HashEntry数组”中的每一个HashEntry元素是一个单向链表。即Segment是通过链式哈希表。第二，Segment是可重入的互斥锁表现在，Segment继承于ReentrantLock，而ReentrantLock就是可重入的互斥锁。  
对于ConcurrentHashMap的添加，删除操作，在操作开始前，线程都会获取Segment的互斥锁；操作完毕之后，才会释放。而对于读取操作，它是通过volatile去实现的，HashEntry数组是volatile类型的，而volatile能保证“即对一个volatile变量的读，总是能看到（任意线程）对这个volatile变量最后的写入”，即我们总能读到其它线程写入HashEntry之后的值。 以上这些方式，就是ConcurrentHashMap线程安全的实现原理。

### **ConcurrentHashMap示例**

下面，我们通过一个例子去对比HashMap和ConcurrentHashMap。

```
import java.util.*;
import java.util.concurrent.*;

/*
 *   ConcurrentHashMap是“线程安全”的哈希表，而HashMap是非线程安全的。
 *
 *   下面是“多个线程同时操作并且遍历map”的示例
 *   (01) 当map是ConcurrentHashMap对象时，程序能正常运行。
 *   (02) 当map是HashMap对象时，程序会产生ConcurrentModificationException异常。
 *
 * @author skywang
 */
public class ConcurrentHashMapDemo1 {

    // TODO: map是HashMap对象时，程序会出错。
    //private static Map<String, String> map = new HashMap<String, String>();
    private static Map<String, String> map = new ConcurrentHashMap<String, String>();
    public static void main(String[] args) {
    
        // 同时启动两个线程对map进行操作！
        new MyThread("ta").start();
        new MyThread("tb").start();
    }

    private static void printAll() {
        String key, value;
        Iterator iter = map.entrySet().iterator();
        while(iter.hasNext()) {
            Map.Entry entry = (Map.Entry)iter.next();
            key = (String)entry.getKey();
            value = (String)entry.getValue();
            System.out.print(key+" - "+value+", ");
        }
        System.out.println();
    }

    private static class MyThread extends Thread {
        MyThread(String name) {
            super(name);
        }
        @Override
        public void run() {
                int i = 0;
            while (i++ < 6) {
                // “线程名” + "-" + "序号"
                String val = Thread.currentThread().getName()+i;
                map.put(String.valueOf(i), val);
                // 通过“Iterator”遍历map。
                printAll();
            }
        }
    }
}
```
**(某一次)运行结果**：
```
- tb1, 
- tb1, 
- tb1, 1 - tb1, 2 - tb2, 
- tb2, 1 - tb1, 
- ta3, 1 - tb1, 2 - tb2, 
- tb3, 1 - tb1, 2 - tb2, 
- tb3, 1 - tb1, 4 - tb4, 3 - tb3, 2 - tb2, 
- tb4, 1 - tb1, 2 - tb2, 
- ta5, 1 - tb1, 3 - tb3, 5 - tb5, 4 - tb4, 3 - tb3, 2 - tb2, 
- tb4, 1 - tb1, 2 - tb2, 
- tb5, 1 - tb1, 6 - tb6, 5 - tb5, 3 - tb3, 6 - tb6, 4 - tb4, 3 - tb3, 2 - tb2, 
- tb4, 2 - tb2,
```
**结果说明**：如果将源码中的map改成HashMap对象时，程序会产生ConcurrentModificationException异常。


