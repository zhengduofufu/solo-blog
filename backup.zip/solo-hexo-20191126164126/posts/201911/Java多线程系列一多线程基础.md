title: Java多线程系列（一） 多线程基础
date: '2019-11-12 15:20:02'
updated: '2019-11-12 15:20:02'
tags: [Java多线程系列]
permalink: /articles/2019/11/12/1573543202538.html
---
![](https://img.hacpai.com/bing/20180110.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

**一、进程**

　　进程是操作系统结构的基础；是一次程序的执行；是一个程序及其数据在处理机上顺序执行时所发生的活动。操作系统中，几乎所有运行中的任务对应一条进程（Process）。一个程序进入内存运行，即变成一个进程。进程是处于运行过程中的程序，并且具有一定独立功能。描述进程的有一句话非常经典——进程是系统进行资源分配和调度的一个独立单位。

　　进程是系统中独立存在的实体，拥有自己独立的资源，拥有自己私有的地址空间**。**进程的实质，就是程序在多道程序系统中的一次执行过程，它是动态产生，动态消亡的，具有自己的生命周期和各种不同的状态。进程具有并发性，它可以同其他进程一起并发执行，按各自独立的、不可预知的速度向前推进。　

（注意，并发性（concurrency）和并行性（parallel）是不同的。并行指的是同一时刻，多个指令在多台处理器上同时运行。并发指的是同一时刻只能有一条指令执行，但多个进程指令被被快速轮换执行，看起来就好像多个指令同时执行一样。）

　　进程由**程序**、**数据**和**进程控制块**三部分组成。

  

**二、线程**

　　线程，有时被称为轻量级进程(Lightweight Process，LWP），是程序执行流的最小单元。一个标准的线程由线程ID，当前指令指针(PC），寄存器集合和堆栈组成。另外，线程是进程中的一个实体，是被系统独立调度和分派的基本单位，**线程自己不拥有系统资源，只拥有一点儿在运行中必不可少的资源，但它可与同属一个进程的其它线程共享进程所拥有的全部资源**。一个线程可以创建和撤消另一个线程，同一进程中的多个线程之间可以并发执行。由于线程之间的相互制约，致使线程在运行中呈现出间断性。每一个程序都至少有一个线程，若程序只有一个线程，那就是程序本身。

　　线程是程序中一个单一的顺序控制流程。在单个程序中同时运行多个线程完成不同的工作，称为多线程。

 　  在Java Web中要注意，线程是JVM级别的，在不停止的情况下，跟JVM共同消亡，就是说如果一个Web服务启动了多个Web应用，某个Web应用启动了某个线 程，如果关闭这个Web应用，线程并不会关闭，因为JVM还在运行，所以别忘了设置Web应用关闭时停止线程。

 

**三、线程状态**

![图片.png](https://img.hacpai.com/file/2019/10/图片-51125840.png)



 线程共包括以下5种状态。  
1. **新建状态(New)**: 线程对象被创建后，就进入了新建状态。此时它和其他Java对象一样，仅仅由Java虚拟机分配了内存，并初始化其成员变量值。  

2. **就绪状态(Runnable)**: 也被称为“可执行状态”。线程对象被调用了该对象的start()方法，该线程处于就绪状态。Java虚拟机会为其创建方法调用栈和程序计数器。处于就绪状态的线程，随时可能被CPU调度执行，取决于JVM中线程调度器的调度。  

3. **运行状态(Running)** : 线程获取CPU权限进行执行。需要注意的是，线程只能从就绪状态进入到运行状态。  

4. **阻塞状态(Blocked)** : 阻塞状态是线程因为某种原因放弃CPU使用权，暂时停止运行。直到线程进入就绪状态，才有机会转到运行状态。阻塞的情况分三种：  
    (01) 等待阻塞 -- 通过调用线程的wait()方法，让线程等待某工作的完成。  
    (02) 同步阻塞 -- 线程在获取synchronized同步锁失败(因为锁被其它线程所占用)，它会进入同步阻塞状态。  
    (03) 其他阻塞 -- 通过调用线程的sleep()或join()或发出了I/O请求时，线程会进入到阻塞状态。当sleep()状态超时、join()等待线程终止或者超时、或者I/O处理完毕时，线程重新转入就绪状态。  

5. **死亡状态(Dead)**    : 线程执行完了、因异常退出了run()方法或者直接调用该线程的stop()方法（容易导致死锁，现在已经不推荐使用），该线程结束生命周期。

  

**四、wait()、notify()、nofityAll()方法**

　　在Object.java中，定义了wait(), notify()和notifyAll()等方法。

　　wait()的作用是让当前线程进入等待状态，同时，**wait()也会让当前线程释放它所持有的锁**。

　　而 notify()和notifyAll()的作用，则是唤醒当前对象上的等待线程；notify()是唤醒单个线程，而notifyAll()是唤醒所有的线程。

Object类中关于等待/唤醒的API详细信息如下：  
　　notify()        -- 唤醒在此对象监视器上等待的单个线程，使其进入“就绪状态”。　　  
　　notifyAll()   -- 唤醒在此对象监视器上等待的所有线程，使其进入“就绪状态”。  
　　wait()                                     -- 让当前线程处于“等待(阻塞)状态”，“直到其他线程调用此对象的 notify() 方法或 notifyAll() 方法”，当前线程被唤醒(进入“就绪状态”)。  
　　wait(long timeout)                 -- 让当前线程处于“等待(阻塞)状态”，“直到其他线程调用此对象的 notify() 方法或 notifyAll() 方法，或者超过指定的时间量”，当前线程被唤醒(进入“就绪状态”)。  
　　wait(long timeout, int nanos) -- 让当前线程处于“等待(阻塞)状态”，“直到其他线程调用此对象的 notify() 方法或 notifyAll() 方法，或者其他某个线程中断当前线程，或者已超过某个实际时间量”，当前线程被唤醒(进入“就绪状态”)。

 **wait()的作用是让“当前线程”等待（会释放锁），而“当前线程”是指正在cpu上运行的线程！**


  

**五、yield()、sleep()、join()和interrupt()方法**

**1、yield()**

　　yield()是Thread类的静态方法。它能让当前线程暂停，但不会阻塞该线程，而是由“运行状态”进入到“就绪状态”，从而让 其它具有相同优先级的等待线程获取执行权；但是，并不能保证在当前线程调用yield()之后，其它具有相同优先级的线程就一定能获得执行权；也有可能是 当前线程又进入到“运行状态”继续运行！

　　值得注意的是，**yield()方法不会释放锁**。

 

**2、sleep()**  

　　sleep()是Thread类的静态方法。该方法声明抛出了InterrupedException异常。所以使用时，要么捕捉，要么声明抛出。

　　有2种重载方式：

——static void sleep(long millis)　　:　　让当前正在执行的线程暂停millis毫秒，并进入阻塞状态，该方法受到系统计时器和线程调度器的精度和准度的影响。  

——static void sleep(long millis , int nanos)　　：　　让当前正在执行的线程暂停millis毫秒加nanos微秒，并进入阻塞状态，该方法受到系统计时器和线程调度器的精度和准度的影响。

　　sleep() 的作用是让当前线程休眠，即当前线程会从“[运行状态]”进入到“[休眠(阻塞)状态]”。sleep()会指定休眠时间，线程休眠的时间会大于/等于该休眠时间；在线程重新被唤醒时，它会由“[阻塞状态]”变成“[就绪状态]”，从而等待cpu的调度执行。常用来暂停程序的运行。　　

　　同时注意，**sleep()方法不会释放锁**。

 

**3、join()**

　　join() 是Thread的一个实例方法。表示，当某个程序执行流中调用其他线程的join方法时，调用线程将被阻塞，直到被join的线程执行完毕。

有3种重载的形式：

——join()　　:　　等待被join的线程执行完成

——join(long millis)　　：　　等待被join的线程的时间最长为millis毫秒，若在millis毫秒内，被join的线程还未执行结束，则不等待。

——join(long millis , int nanos)　　:　　等待被join的线程的时间最长为millis毫秒加nanos微秒，若在此时间内，被join的线程还未执行结束，则不等待。

即当前线程内，用某个线程对象调用join()后，会使当前线程等待，直到该线程对象的线程运行完毕，原线程才会继续运行。

 

**4、interrupt()**　

　　我们经常通过判断线程的中断标记来控制线程。　 　

　　interrupt()是Thread类的一个实例方法，用于中断本线程。这个方法被调用时，会立即将线程的中断标志设置为“true”。所以当中断处于“阻塞状态”的线程时，由于处于阻塞状态，中断标记会被设置为“false”，抛出一个 InterruptedException。所以我们在线程的循环外捕获这个异常，就可以退出线程了。

　　interrupt()并不会中断处于“运行状态”的线程，它会把线程的“中断标记”设置为true，所以我们可以不断通过isInterrupted()来检测中断标记，从而在调用了interrupt()后终止线程，这也是通常我们对interrupt()的用法。

　　Interrupted()是Thread类的一个静态方法，它返回一个布尔类型指明当前线程是否已经被中断，isInterrupted()是Thread类的实例方法，返回一个布尔类型来判断线程是否已经被中断。它们都能够用于检测对象的“中断标记”。区别是，interrupted()除了返回中断标记之外，它还会清除中断标记(即将中断标记设为false)；而isInterrupted()仅仅返回中断标记。

## 6.Java多线程的创建及启动
**1.继承Thread类，重写该类的run()方法。**


```
class MyThread extends Thread {
    
    private int i = 0;

    @Override
    public void run() {
        for (i = 0; i < 100; i++) {
            System.out.println(Thread.currentThread().getName() + " " + i);
        }
    }
}


```
```
public class ThreadTest {

    public static void main(String[] args) {
        for (int i = 0; i < 100; i++) {
            System.out.println(Thread.currentThread().getName() + " " + i);
            if (i == 30) {
                Thread myThread1 = new MyThread();     // 创建一个新的线程  myThread1  此线程进入新建状态
                Thread myThread2 = new MyThread();     // 创建一个新的线程 myThread2 此线程进入新建状态
                myThread1.start();                     // 调用start()方法使得线程进入就绪状态
                myThread2.start();                     // 调用start()方法使得线程进入就绪状态
            }
        }
    }
}
```


如上所示，继承Thread类，通过重写run()方法定义了一个新的线程类MyThread，其中run()方法的方法体代表了线程需要完成的任务，称之为线程执行体。当创建此线程类对象时一个新的线程得以创建，并进入到线程新建状态。通过调用线程对象引用的start()方法，使得该线程进入到就绪状态，此时此线程并不一定会马上得以执行，这取决于CPU调度时机。

**2.实现Runnable接口，并重写该接口的run()方法，该run()方法同样是线程执行体，创建Runnable实现类的实例，并以此实例作为Thread类的target来创建Thread对象，该Thread对象才是真正的线程对象。**
```


class MyRunnable implements Runnable {
    private int i = 0;

    @Override
    public void run() {
        for (i = 0; i < 100; i++) {
            System.out.println(Thread.currentThread().getName() + " " + i);
        }
    }
}
```
```
public class ThreadTest {

    public static void main(String[] args) {
        for (int i = 0; i < 100; i++) {
            System.out.println(Thread.currentThread().getName() + " " + i);
            if (i == 30) {
                Runnable myRunnable = new MyRunnable(); // 创建一个Runnable实现类的对象
                Thread thread1 = new Thread(myRunnable); // 将myRunnable作为Thread target创建新的线程
                Thread thread2 = new Thread(myRunnable);
                thread1.start(); // 调用start()方法使得线程进入就绪状态
                thread2.start();
            }
        }
    }
}
```
**Thread和Runable的区别**

1. Thread是基类，子类必继承他实现其run方法。其也是实现了Runable接口。Thread是普通的类，并非抽象类或者密封类等。
2. Runnable是接口，子类必须实现run方法，该接口就只有唯一的抽象方法run。
3. 由于Java单继承，所以Thead通过类继承方式实现接口，存在扩展性问题。
4. 他们都是通过start方法来启动，可以达到异步操作，如果用run方法启动其将是同步方法，失去多线程的意义。
5. Runnable，的实现类可以实现资源共享，多个调用只需要实例化Runnable的一个实例，然后将其放到 new Thread（new Runnable实现类）.start方法（可以new多个一样的即表示多个线程），启动。
6. 实验发现在实现Runnable的多线程中，如果同时启动的实例过多会在第一次执行的时候出现多线程并发，主要出现在开始，有肯能是程序启动加载资源导致，大多度数时候还是稳定的。比如实现的run方法控制了10个实际new 的个数太多久会出现，但是频率不高。
7. 可以在Thread中实现匿名方法也可以实现多线程异步华。
8. 主线程结束，子线程可以继续执行。
9. 在java中，每次程序运行至少启动2个线程。一个是main线程，一个是垃圾收集线程。

