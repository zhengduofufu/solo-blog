title: Activity从入门到 入土（ 整合Spring）
date: '2019-10-31 16:41:11'
updated: '2019-10-31 16:41:11'
tags: [Activity]
permalink: /articles/2019/10/31/1572511271813.html
---
![](https://img.hacpai.com/bing/20180914.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 一、前言

在上一节中，通过一个[入门程序]，把activiti的环境准备好了，这一节，将整合spring，并且部署一个最简单的bpmn流程图。

### 二、环境准备

这一节的内容在上一节[入门程序]的基础上进行环境配置，如果需要完整的配置文件，请到上一节查看。

#### 2.1 spring配置

首先，需要添加spring的配置文件

```
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:tx="http://www.springframework.org/schema/tx" xmlns="http://www.springframework.org/schema/beans"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd     http://www.springframework.org/schema/tx http://www.springframework.org/schema/tx/spring-tx.xsd">

    <bean id="propertyConfigurer" class="org.springframework.beans.factory.config.PropertyPlaceholderConfigurer">
        <property name="ignoreUnresolvablePlaceholders" value="true"/>
        <property name="locations">
            <list>
                <value>classpath:settings.properties</value>
            </list>
        </property>
    </bean>

    <bean id="dataSource" class="com.alibaba.druid.pool.DruidDataSource" init-method="init" destroy-method="close">
        <property name="driverClassName" value="${db.driverClassName}"/>
        <property name="url" value="${db.url}"/>
        <property name="username" value="${db.username}"/>
        <property name="password" value="${db.password}"/>
        <property name="initialSize" value="3"/>
        <property name="minIdle" value="3"/>
        <property name="maxActive" value="20"/>
        <property name="maxWait" value="60000"/>
        <property name="filters" value="stat,wall"/>
    </bean>

    <!-- tx -->
    <bean id="transactionManager" class="org.springframework.jdbc.datasource.DataSourceTransactionManager">
        <property name="dataSource" ref="dataSource"/>
    </bean>

    <tx:annotation-driven transaction-manager="transactionManager"/>

    <!-- druid -->
    <bean id="stat-filter" class="com.alibaba.druid.filter.stat.StatFilter">
        <property name="slowSqlMillis" value="3000"/>
        <property name="logSlowSql" value="true"/>
        <property name="mergeSql" value="true"/>
    </bean>
    <bean id="wall-filter" class="com.alibaba.druid.wall.WallFilter">
        <property name="dbType" value="mysql"/>
    </bean>

</beans>

```

#### 2.2 数据库等环境配置文件

然后，添加数据库等环境配置文件

```
db.driverClassName=com.mysql.jdbc.Driver
db.url=jdbc:mysql://localhost:3306/activitiTest?useUnicode=true&characterEncoding=UTF-8
db.username=root
db.password=123456

```

到目前为止，就把spring的配置环境搭建好了，接下来，我们需要加入activiti的整合环境的配置了。

#### 2.3 spring整合activiti

这一步，我们加入spring整合activiti环境的配置

```
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:p="http://www.springframework.org/schema/p"
       xmlns="http://www.springframework.org/schema/beans"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">

    <!-- 配置流程引擎配置信息对象 -->
    <bean id="processEngineConfiguration" class="org.activiti.spring.SpringProcessEngineConfiguration"
          p:dataSource-ref="dataSource"
          p:transactionManager-ref="transactionManager"
          p:databaseSchemaUpdate="true"
          p:jobExecutorActivate="false"
          p:databaseType="mysql"
          p:activityFontName="宋体"
          p:labelFontName="黑体"
          p:xmlEncoding="utf-8"/>

    <!-- 配置流程引擎 -->
    <bean id="processEngine" class="org.activiti.spring.ProcessEngineFactoryBean"
          p:processEngineConfiguration-ref="processEngineConfiguration"/>

    <!-- 配置六个服务Bean -->
    <bean id="repositoryService" factory-bean="processEngine"
          factory-method="getRepositoryService"/>
    <bean id="runtimeService" factory-bean="processEngine"
          factory-method="getRuntimeService"/>
    <bean id="taskService" factory-bean="processEngine"
          factory-method="getTaskService"/>
    <bean id="historyService" factory-bean="processEngine"
          factory-method="getHistoryService"/>
    <bean id="formService" factory-bean="processEngine"
          factory-method="getFormService"/>
    <bean id="identityService" factory-bean="processEngine"
          factory-method="getIdentityService"/>

</beans>

```

到2.3这一步，spring整合activiti的环境就配置好了，接下来，我们创建一个简单的bpmn文件，然后，做一个简单的测试，部署bpmn文件。

### 三、部署实例

#### 3.1 绘制

打开idea的bpmn编辑器，绘制一个简单的bpmn文件，如下  
![图片.png](https://img.hacpai.com/file/2019/09/图片-db18e809.png)


  
**注意：** 用idea编辑的时候，是不会和eclipse一样会自动的生成`png文件`的，这里有两种方式解决。

**方式一**

用eclipse打开编辑，会自动生成，这个简单，这里就不多说了。

**方式二**

将`bpmn`后缀改为`xml`  

![图片.png](https://img.hacpai.com/file/2019/09/图片-cece9b1a.png)


  
右键xml文件，找到下面的按键  

![图片.png](https://img.hacpai.com/file/2019/09/图片-9b60f300.png)


出现下面的界面  

![图片.png](https://img.hacpai.com/file/2019/09/图片-2e1da5b3.png)


右键，选择`export to file`  

![图片.png](https://img.hacpai.com/file/2019/09/图片-e0d356c2.png)


生成如下  
![图片.png](https://img.hacpai.com/file/2019/09/图片-05e4b934.png)


最后将`xml`后缀改为`bpmn`

#### 3.2 测试

通过上面的介绍，绘制了`bpmn文件`和`png图片`，下面写一个测试实例，部署流程。

```
/**
 * @Author Anthony
 * @Description 部署
 * @Date 16:24 2019/9/26
 * @Param
 * @return
 **/
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:applicationContext-core.xml",
        "classpath:applicationContext-activiti.xml"
})
@Slf4j
public class test02_spring {

    @Autowired
    private ProcessEngine processEngine;
    @Autowired
    private TaskService taskService;
    @Autowired
    private RuntimeService runtimeService;
    @Autowired
    private HistoryService historyService;

    /**
     * @return void
     * @Author Anthony
     * @Description 部署流程实例
     * @Date 16:17 2019/9/26
     * @Param []
     **/
    @Test
    public void testTask() throws Exception {
        // 1 发布流程
        InputStream inputStreamBpmn = this.getClass().getResourceAsStream("/bpmn/test_01.xml");
        InputStream inputStreamPng = this.getClass().getResourceAsStream("/bpmn/test_01.png");
        processEngine.getRepositoryService()
                .createDeployment()
                .addInputStream("test_01.xml", inputStreamBpmn)
                .addInputStream("test_01.png", inputStreamPng)
                .deploy();

        ProcessInstance pi = processEngine.getRuntimeService()//
                .startProcessInstanceByKey("test_01");
        System.out.println("pid:" + pi.getId());
    }
}

```

注意上面的`test_01`是你的bpmn文件的`id`。

#### 3.3 测试结果
![图片.png](https://img.hacpai.com/file/2019/09/图片-4d978f71.png)


### 四、总结

这一节通过整合spring，绘制简单的bpmn文件，然后成功部署了bpmn文件。下一节，将讲解activit的`API`



