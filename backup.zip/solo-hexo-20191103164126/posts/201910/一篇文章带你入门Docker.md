title: 一篇文章带你入门Docker
date: '2019-10-31 09:35:37'
updated: '2019-10-31 09:35:37'
tags: [Docker]
permalink: /articles/2019/10/31/1572485736922.html
---
![](https://img.hacpai.com/bing/20171108.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


## 什么是Docker
我们在理解 `docker` 之前，首先我们得先区分清楚两个概念，**容器**和**虚拟机**。

可能很多读者朋友都用过虚拟机，而对容器这个概念比较的陌生。

我们用的传统虚拟机如 `VMware` ， `VisualBox` 之类的需要模拟整台机器包括硬件，每台虚拟机都需要有自己的操作系统，虚拟机一旦被开启，预分配给它的资源将全部被占用。每一台虚拟机包括应用，必要的二进制和库，以及一个完整的用户操作系统。

而容器技术是和我们的宿主机共享硬件资源及操作系统，可以实现资源的动态分配。容器包含应用和其所有的依赖包，但是与其他容器共享内核。容器在宿主机操作系统中，在用户空间以分离的进程运行。

容器技术是实现操作系统虚拟化的一种途径，可以让您在资源受到隔离的进程中运行应用程序及其依赖关系。通过使用容器，我们可以轻松打包应用程序的代码、配置和依赖关系，将其变成容易使用的构建块，从而实现环境一致性、运营效率、开发人员生产力和版本控制等诸多目标。容器可以帮助保证应用程序快速、可靠、一致地部署，其间不受部署环境的影响。容器还赋予我们对资源更多的精细化控制能力，让我们的基础设施效率更高。通过下面这幅图我们可以很直观的反映出这两者的区别所在。

![图片.png](https://img.hacpai.com/file/2019/09/图片-068418b4.png)

**Docker 属于 Linux 容器的一种封装，提供简单易用的容器使用接口**。它是目前最流行的 `Linux` 容器解决方案。

而 `Linux` 容器是 `Linux` 发展出了另一种虚拟化技术，简单来讲， `Linux` 容器不是模拟一个完整的操作系统，而是对进程进行隔离，相当于是在正常进程的外面套了一个保护层。对于容器里面的进程来说，它接触到的各种资源都是虚拟的，从而实现与底层系统的隔离。

`Docker` 将应用程序与该程序的依赖，打包在一个文件里面。运行这个文件，就会生成一个虚拟容器。程序在这个虚拟容器里运行，就好像在真实的物理机上运行一样。有了 `Docker` ，就不用担心环境问题。

总体来说， `Docker` 的接口相当简单，用户可以方便地创建和使用容器，把自己的应用放入容器。容器还可以进行版本管理、复制、分享、修改，就像管理普通的代码一样。

## Docker的应用场景

* Web 应用的自动化打包和发布。
    
* 自动化测试和持续集成、发布。
    
* 在服务型环境中部署和调整数据库或其他的后台应用。
    
* 从头编译或者扩展现有的 OpenShift 或 Cloud Foundry 平台来搭建自己的 PaaS 环境。

## Docker 的优点

* **1、简化程序：**  
    Docker 让开发者可以打包他们的应用以及依赖包到一个可移植的容器中，然后发布到任何流行的 Linux 机器上，便可以实现虚拟化。Docker改变了虚拟化的方式，使开发者可以直接将自己的成果放入Docker中进行管理。方便快捷已经是 Docker的最大优势，过去需要用数天乃至数周的 任务，在Docker容器的处理下，只需要数秒就能完成。
    
* **2、避免选择恐惧症：**  
    如果你有选择恐惧症，还是资深患者。那么你可以使用 Docker 打包你的纠结！比如 Docker 镜像；Docker 镜像中包含了运行环境和配置，所以 Docker 可以简化部署多种应用实例工作。比如 Web 应用、后台应用、数据库应用、大数据应用比如 Hadoop 集群、消息队列等等都可以打包成一个镜像部署。
    
* **3、节省开支：**  
    一方面，云计算时代到来，使开发者不必为了追求效果而配置高额的硬件，Docker 改变了高性能必然高价格的思维定势。Docker 与云的结合，让云空间得到更充分的利用。不仅解决了硬件管理的问题，也改变了虚拟化的方式。


| 特性 |  容器 |  虚拟机 |
| --- |  --- |  --- |
| 启动 |  秒级 |  分钟级 |
| 硬盘使用 |  一般为MB |  一般为GB |
| 性能 |  接近原生 |  弱于 |
| 系统支持量 |  单机支持上千个容器 |  一般是几十个 |

### Docker的三个基本概念
![图片.png](https://img.hacpai.com/file/2019/09/图片-9fc62d19.png)

从上图我们可以看到，`Docker` 中包括三个基本的概念：

* `Image`(镜像)
* `Container`(容器)
* `Repository`(仓库)

# Docker 镜像与容器

说到 Docker ，你会常遇到两个内容：
image(镜像)
关于镜像，你可以这样来理解：镜像是构建 Docker 的基石，用户基于镜像来运行自己的容器，镜像可以看作是一个特殊的文件系统，除了提供容器运行时所需的程序、库、资源、配置等文件外，还包含了一些为运行时准备的一些配置参数（如匿名卷、环境变量、用户等）。镜像不包含任何动态数据，其内容在构建之后也不会被改变，镜像`（Image）`就是一堆只读层`（read-only layer）`的统一视角，也许这个定义有些难以理解，下面的这张图能够帮助读者理解镜像的定义。

![图片.png](https://img.hacpai.com/file/2019/09/图片-773dc270.png)


从左边我们看到了多个只读层，它们重叠在一起。除了最下面一层，其它层都会有一个指针指向下一层。这些层是`Docker` 内部的实现细节，并且能够在主机的文件系统上访问到。统一文件系统 `(union file system)` 技术能够将不同的层整合成一个文件系统，为这些层提供了一个统一的视角，这样就隐藏了多层的存在，在用户的角度看来，只存在一个文件系统。我们可以在图片的右边看到这个视角的形式。

 container (即容器)
容器 `(container)` 的定义和镜像 `(image)` 几乎一模一样，也是一堆层的统一视角，唯一区别在于容器的最上面那一层是可读可写的。

![图片.png](https://img.hacpai.com/file/2019/09/图片-1dc11d95.png)

由于容器的定义并没有提及是否要运行容器，所以实际上，容器 = 镜像 + 读写层。

镜像是 Docker 生命周期中的构建或打包阶段，而容器则是启动或是执行阶段。好吧，说的再明白点儿，就是有了镜像，才有的容器。容器是在镜像的基础上，才有的。

Repository (仓库)

`Docker` 仓库是集中存放镜像文件的场所。镜像构建完成后，可以很容易的在当前宿主上运行，但是， 如果需要在其它服务器上使用这个镜像，我们就需要一个集中的存储、分发镜像的服务，`Docker Registry` (仓库注册服务器)就是这样的服务。有时候会把仓库 `(Repository)` 和仓库注册服务器 `(Registry)` 混为一谈，并不严格区分。`Docker` 仓库的概念跟 `Git` 类似，注册服务器可以理解为 `GitHub` 这样的托管服务。实际上，一个 `Docker Registry` 中可以包含多个仓库 `(Repository)` ，每个仓库可以包含多个标签 `(Tag)`，每个标签对应着一个镜像。所以说，镜像仓库是 `Docker` 用来集中存放镜像文件的地方类似于我们之前常用的代码仓库。

通常，**一个仓库会包含同一个软件不同版本的镜像**，而**标签就常用于对应该软件的各个版本** 。我们可以通过`<仓库名>:<标签>`的格式来指定具体是这个软件哪个版本的镜像。如果不给出标签，将以 `latest` 作为默认标签.。

仓库又可以分为两种形式：

* `public`(公有仓库)
* `private`(私有仓库)

`Docker Registry` 公有仓库是开放给用户使用、允许用户管理镜像的 `Registry` 服务。一般这类公开服务允许用户免费上传、下载公开的镜像，并可能提供收费服务供用户管理私有镜像。

除了使用公开服务外，用户还可以在本地搭建私有 `Docker Registry` 。`Docker` 官方提供了 `Docker Registry`镜像，可以直接使用做为私有 `Registry` 服务。当用户创建了自己的镜像之后就可以使用 `push` 命令将它上传到公有或者私有仓库，这样下次在另外一台机器上使用这个镜像时候，只需要从仓库上 `pull` 下来就可以了。

![图片.png](https://img.hacpai.com/file/2019/09/图片-30a22dd8.png)
这张图展示了 `Docker` 客户端、服务端和 `Docker` 仓库（即 `Docker Hub` 和 `Docker Cloud` ），默认情况下`Docker` 会在 `Docker` 中央仓库寻找镜像文件，这种利用仓库管理镜像的设计理念类似于 `Git` ，当然这个仓库是可以通过修改配置来指定的，甚至我们可以创建我们自己的私有仓库。

# Docker 安装
`Docker` 软件包已经包括在默认的 `CentOS-Extras` 软件源里。因此想要安装 `docker`，只需要运行下面的 `yum` 命令

```
$ sudo yum install docker
```
安装成功后可通过下面命令查看docker版本信息
```
$ docker version 
or
docker info
```

# Docker 相关命令

## Docker 操作相关命令：

```
systemctl start docker		启动 dockersystemctl status docker		查看 docker 状态systemctl stop docker		停止 dockersystemctl enable docker		开机自启docker info 			查看 docker 概要信息docker --help			查看 docker 帮助文档
```

## 镜像相关命令：

查看镜像命令：

```
docker images
```

搜索镜像：

```
docker search 镜像名称
```

拉取镜像:
```
docker pull image_name
```

## 容器相关命令：

**查看容器** ：查看正在运行的容器：

```
docker ps
```

查看所有容器：

```
docker ps -a
```

查看最后一次运行的容器：

```
docker ps -l
```

查看停止的容器：

```
docker ps -f status=exited
```

**创建容器:**

```
docker run
```

可以在 run 后面加参数。其中：

```
-i   表示运行容器-t   表示容器启动后进入其命令行--name  为创建的容器命名-v     表示目录映射关系(前者是宿主机目录，后者是映射到宿主机上的目录)-d     在 run 后面加上 -d 参数，则会创建一个守护式容器在后台运行-p     表示端口映射，前者是宿主机端口，后者是容器内的映射端口
```

交互式方式创建容器

```
docker run -it --name=容器名称 镜像名称：标签 /bin/bash
```

守护式方式创建容器

```
docker run -di --name=容器名称 镜像名称：标签
```

登录守护式容器方式

```
docker exec -it 容器名称(或容器 ID) /bin/bash
```

**启动容器:**

```
docker start 容器名称(或容器 ID)
```

**停止容器:**

```
docker stop 容器名称(或容器 ID)
```

## 文件拷贝：

将文件拷贝到容器内

```
docker cp 需要拷贝的文件或目录  容器名称：容器目录
```

将文件从容器内拷贝出来

```
docker cp 容器名称：容器目录	需要拷贝的文件或目录
```

## 目录挂载：

在创建容器时，将宿主机的目录与容器内的目录进行映射，这样可以通过修改宿主机某个目录的文件从而去影响容器 创建容器 添加 -v 参数 后边为 宿主机目录：容器目录，完整命令：

```
docker run  -v 宿主机目录：容器目录
```

如果共享的是多级目录，可能会出现权限不足的情况 可以通过添加参数 --privileged=true 来解决，因为 CentOS7 中安全模块将 selinux 权限禁掉了，添加此参数，可以将问题解决。

## 查看容器 IP：

```
docker inspect 容器名称(容器 ID )
```

也可以直接输出 IP 地址：

```
docker inspect --format='{{NetworkSetting。IPAddress}}' 容器名称(容器 ID)
```

## 删除容器

```
docker rm 容器名称(容器 ID)
```

# 常见的应用部署

## MySQL 部署：

1 ，拉取镜像：

```
docker pull centos/mysql-57-centos7
```

2 ，创建容器：

```
docker run -di --name=mysql -p 3306：3306 -e MYSQL_ROOT_PASSWORD=root centos/mysql-57-centos7
```

其中：-p 代表端口映射，格式为 宿主机映射端口：容器运行端口 -e 代表添加环境变量 MYSQL_ROOT_PASSWORD 是 root 用户的登录密码 3 ，进入 mysql 容器：

```
docker exec -it mysql /bin/bash
```

4 ，登录 mysql ：

```
mysql -u root -p
```

## tomcat 部署：

1 ，拉取镜像

```
docker pull tomcat：7-jre7
```

2 ，创建容器

```
docker run -di --name=mytomcat -p 9000：8080 -v /usr/local/webapps:/usr/local/webapps tomcat：7-jre7
```

## Nginx 部署：

1 ，拉取镜像

```
docker pull nginx
```

2 ，创建 nginx 容器

```
docker run -di --name=mynginx -p 80：80 nginx
```

## Redis 部署：

1 ，拉取镜像

```
docker pull redis
```

2 ，创建 redis 容器

```
docker run -di --name=myredis -p 6379：6379 redis
```

# 迁移与备份

容器保存为镜像：

```
docker commit 容器名称 镜像名称
```

例：

```
docker commit mynginx mynginx_i
```

将镜像保存为 tar 文件，例：

```
docker save -o mynginx。tar mynginx_i
```

镜像恢复与迁移：-i 输入的文件，例：

```
docker load -i mynginx。tar
```

# Dockerfile

Dockerfile 是由一系列命令和参数构成的脚本，基于基础镜像，最终创建一个新的镜像，常用命令有：

```
FROM image_name：tag  定义了使用哪儿个基础镜像启动构建流程MAINTAINER user_name	声明镜像的创建者ENV key value		设置环境变量(可以写多条)RUN command 		是 Dockerfile 的核心部分(可以写多条)ADD source_dir/file dest_dir/file  将宿主机的文件复制到容器内，如果是一个压缩文件，将会在复制后自动解压COPY source_dir/file dest_dir/file   和 ADD 相似，但是如果有压缩文件并不能解压WORDIR path_dir 设置工作目录
```

需要注意一下，如果要使用 Dockerfile 文件，名字必须为「Dockerfile」,否则里面的命令不会有效。

###  Docker常用命令大全
![图片.png](https://img.hacpai.com/file/2019/09/图片-cc177197.png)




