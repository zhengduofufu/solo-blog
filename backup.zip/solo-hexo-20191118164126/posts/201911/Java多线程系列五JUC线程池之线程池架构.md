title: Java多线程系列（五） JUC线程池 之 线程池架构
date: '2019-11-12 15:30:51'
updated: '2019-11-12 15:30:51'
tags: [Java多线程系列]
permalink: /articles/2019/11/12/1573543851345.html
---
![](https://img.hacpai.com/bing/20171227.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### **线程池架构图**

线程池的架构图如下：
![图片.png](https://img.hacpai.com/file/2019/10/图片-90506228.png)

**1. Executor**

它是"执行者"接口，它是来执行任务的。准确的说，Executor提供了execute()接口来执行已提交的 Runnable 任务的对象。Executor存在的目的是提供一种将"任务提交"与"任务如何运行"分离开来的机制。  
它只包含一个函数接口：
```
void execute(Runnable command)
```
**2. ExecutorService**

ExecutorService继承于Executor。它是"执行者服务"接口，它是为"执行者接口Executor"服务而存在的；准确的话，ExecutorService提供了"将任务提交给执行者的接口(submit方法)"，"让执行者执行任务(invokeAll, invokeAny方法)"的接口等等。

**3. AbstractExecutorService**

AbstractExecutorService是一个抽象类，它实现了ExecutorService接口。  
AbstractExecutorService存在的目的是为ExecutorService中的函数接口提供了默认实现。

**4. ThreadPoolExecutor**

ThreadPoolExecutor就是大名鼎鼎的"线程池"。它继承于AbstractExecutorService抽象类。

**5. ScheduledExecutorService**

ScheduledExecutorService是一个接口，它继承于于ExecutorService。它相当于提供了"延时"和"周期执行"功能的ExecutorService。  
ScheduledExecutorService提供了相应的函数接口，可以安排任务在给定的延迟后执行，也可以让任务周期的执行。

**6. ScheduledThreadPoolExecutor**

ScheduledThreadPoolExecutor继承于ThreadPoolExecutor，并且实现了ScheduledExecutorService接口。它相当于提供了"延时"和"周期执行"功能的ScheduledExecutorService。  
ScheduledThreadPoolExecutor类似于Timer，但是在高并发程序中，ScheduledThreadPoolExecutor的性能要优于Timer。

**7. Executors**

Executors是个静态工厂类。它通过静态工厂方法返回ExecutorService、ScheduledExecutorService、ThreadFactory 和 Callable 等类的对象。
### **线程池示例**

下面通过示例来对线程池的使用做简单演示。
```
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

public class ThreadPoolDemo1 {

    public static void main(String[] args) {
        // 创建一个可重用固定线程数的线程池
        ExecutorService pool = Executors.newFixedThreadPool(2);
        // 创建实现了Runnable接口对象，Thread对象当然也实现了Runnable接口
        Thread ta = new MyThread();
        Thread tb = new MyThread();
        Thread tc = new MyThread();
        Thread td = new MyThread();
        Thread te = new MyThread();
        // 将线程放入池中进行执行
        pool.execute(ta);
        pool.execute(tb);
        pool.execute(tc);
        pool.execute(td);
        pool.execute(te);
        // 关闭线程池
        pool.shutdown();
    }
}

class MyThread extends Thread {

    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName()+ " is running.");
    }
}
```

**运行结果**：
```
pool-1-thread-1 is running.
pool-1-thread-2 is running.
pool-1-thread-1 is running.
pool-1-thread-2 is running.
pool-1-thread-1 is running.
```

**结果说明**：  
主线程中创建了线程池pool，线程池的容量是2。即，线程池中最多能同时运行2个线程。  
紧接着，将ta,tb,tc,td,te这3个线程添加到线程池中运行。  
最后，通过shutdown()关闭线程池。






















